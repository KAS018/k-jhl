/* =========================================================================
   أدوات مشتركة تُستخدم من كل الدوال (functions/api/*.js).
   Shared utilities used by every function in functions/api/*.js.
   لا يوجد هنا أي مفتاح سرّي — كل المفاتيح تُقرأ من env في وقت التشغيل.
   No secrets live here — every key is read from env at request time.
   ========================================================================= */

export function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

// ---------- Password hashing (PBKDF2 via Web Crypto — no external deps) ----------
async function pbkdf2(password, saltBytes, iterations = 100000) {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt: saltBytes, iterations, hash: "SHA-256" },
    keyMaterial,
    256
  );
  return new Uint8Array(bits);
}

function toHex(bytes) {
  return [...bytes].map((b) => b.toString(16).padStart(2, "0")).join("");
}
function fromHex(hex) {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i++) bytes[i] = parseInt(hex.substr(i * 2, 2), 16);
  return bytes;
}

// يُستخدم مرة واحدة عند إنشاء المدير (راجع README خطوة 4)
export async function hashPassword(password) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const derived = await pbkdf2(password, salt);
  return `${toHex(salt)}:${toHex(derived)}`;
}

export async function verifyPassword(password, stored) {
  const [saltHex, hashHex] = stored.split(":");
  const derived = await pbkdf2(password, fromHex(saltHex));
  return toHex(derived) === hashHex;
}

// ---------- Admin session token: HMAC-signed, expires after 12h ----------
async function hmac(secret, message) {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(message));
  return toHex(new Uint8Array(sig));
}

export async function signToken(username, secret) {
  const payload = JSON.stringify({ u: username, exp: Date.now() + 12 * 60 * 60 * 1000 });
  const b64 = btoa(payload);
  const sig = await hmac(secret, b64);
  return `${b64}.${sig}`;
}

export async function verifyToken(token, secret) {
  if (!token) return null;
  const [b64, sig] = token.split(".");
  if (!b64 || !sig) return null;
  const expected = await hmac(secret, b64);
  if (expected !== sig) return null;
  try {
    const payload = JSON.parse(atob(b64));
    if (payload.exp < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

export async function requireAdmin(request, env) {
  const auth = request.headers.get("Authorization") || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  const payload = await verifyToken(token, env.ADMIN_SESSION_SECRET);
  return payload; // null إذا غير صالح / null if invalid
}

export function randomCode(len = 8) {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out = "";
  for (let i = 0; i < len; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}
