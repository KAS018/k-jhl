import { json, requireAdmin } from "../_utils.js";

// PATCH /api/admin-images  { id, price, quantity }  (requires admin token)
export async function onRequestPatch({ request, env }) {
  const admin = await requireAdmin(request, env);
  if (!admin) return json({ error: "unauthorized" }, 401);

  const { id, price, quantity } = await request.json();
  const p = Math.min(100000, Math.max(1, Number(price)));
  const q = Math.max(1, parseInt(quantity, 10));

  await env.DB.prepare("UPDATE rare_images SET price = ?, quantity = ? WHERE id = ?")
    .bind(p, q, id)
    .run();

  return json({ ok: true });
}
