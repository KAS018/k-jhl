import { json } from "../_utils.js";

// GET /api/get-images -> { items: [...] }
export async function onRequestGet({ env }) {
  const { results } = await env.DB.prepare(
    "SELECT id, image_url, description_ar, description_en, price, quantity, code, created_at FROM rare_images ORDER BY created_at DESC LIMIT 60"
  ).all();
  return json({ items: results });
}
