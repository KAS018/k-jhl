import { json } from "../_utils.js";

/* =========================================================================
   هذا الملف لا يحتوي منطق استخراج فيديو بنفسه — بل يعتمد على خدمة API خارجية
   متخصصة تشترك فيها (مثلاً من RapidAPI)، لأن كل منصة (تيك توك/انستغرام/يوتيوب)
   تغيّر بنيتها باستمرار وتفرض شروط استخدام خاصة بها.
   ضع رابط ومفتاح تلك الخدمة في متغيرات البيئة: DOWNLOAD_API_URL, DOWNLOAD_API_KEY
   راجع README خطوة 8.

   This file has no scraping logic of its own — it forwards to a third-party
   download API you subscribe to (e.g. via RapidAPI), because each platform's
   internal structure and terms of service change constantly.
   Set DOWNLOAD_API_URL and DOWNLOAD_API_KEY as environment variables.
   See README step 8.
   ========================================================================= */
export async function onRequestPost({ request, env }) {
  const { url } = await request.json();
  if (!url) return json({ error: "missing url" }, 400);

  if (!env.DOWNLOAD_API_URL || !env.DOWNLOAD_API_KEY) {
    return json({ error: "Download service not configured yet / خدمة التنزيل غير مفعّلة بعد" }, 501);
  }

  try {
    const res = await fetch(env.DOWNLOAD_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${env.DOWNLOAD_API_KEY}`,
      },
      body: JSON.stringify({ url }),
    });
    const data = await res.json();
    // عدّل اسم الحقل هنا حسب استجابة الخدمة التي اخترتها
    // Adjust this field name to match your chosen provider's response shape
    return json({ download_url: data.download_url || data.url || null });
  } catch (e) {
    return json({ error: "Download provider error" }, 502);
  }
}
