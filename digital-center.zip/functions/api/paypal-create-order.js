import { json } from "../_utils.js";

// عدّل هذا الرابط إلى api-m.paypal.com عند الانتقال للوضع الحقيقي (Live)
// Switch this to api-m.paypal.com when you move from Sandbox to Live
const PAYPAL_API = "https://api-m.sandbox.paypal.com";

async function getAccessToken(env) {
  const auth = btoa(`${env.PAYPAL_CLIENT_ID}:${env.PAYPAL_SECRET}`);
  const res = await fetch(`${PAYPAL_API}/v1/oauth2/token`, {
    method: "POST",
    headers: {
      "Authorization": `Basic ${auth}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials",
  });
  const data = await res.json();
  return data.access_token;
}

// POST /api/paypal-create-order  { kind, item_id, amount }
export async function onRequestPost({ request, env }) {
  const { amount } = await request.json();
  const safeAmount = Math.min(100000, Math.max(1, Number(amount) || 1)).toFixed(2);

  const accessToken = await getAccessToken(env);
  const res = await fetch(`${PAYPAL_API}/v2/checkout/orders`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      intent: "CAPTURE",
      purchase_units: [{ amount: { currency_code: "USD", value: safeAmount } }],
    }),
  });
  const order = await res.json();
  return json(order);
}
