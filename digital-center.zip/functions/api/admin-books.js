import { json, requireAdmin } from "../_utils.js";

// POST /api/admin-books  { title_ar, title_en, cover_url, file_url, price }  (requires admin token)
export async function onRequestPost({ request, env }) {
  const admin = await requireAdmin(request, env);
  if (!admin) return json({ error: "unauthorized" }, 401);

  const { title_ar, title_en, cover_url, file_url, price } = await request.json();
  if (!title_ar && !title_en) return json({ error: "missing title" }, 400);

  const p = Math.min(100000, Math.max(1, Number(price) || 1));

  await env.DB.prepare(
    "INSERT INTO books (title_ar, title_en, cover_url, file_url, price, created_at) VALUES (?, ?, ?, ?, ?, ?)"
  ).bind(title_ar || "", title_en || "", cover_url || "", file_url || "", p, Date.now()).run();

  return json({ ok: true });
}
