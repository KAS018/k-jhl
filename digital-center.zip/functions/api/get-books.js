import { json } from "../_utils.js";

// GET /api/get-books -> { items: [...] }
export async function onRequestGet({ env }) {
  const { results } = await env.DB.prepare(
    "SELECT id, title_ar, title_en, cover_url, price, created_at FROM books ORDER BY created_at DESC LIMIT 100"
  ).all();
  return json({ items: results });
}
