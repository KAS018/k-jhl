import { json } from "../_utils.js";

const SERVICE_LABELS = {
  "whatsapp-bot": "WhatsApp Bot / بوت واتساب",
  "website": "Website Development / إنشاء موقع إلكتروني",
  "other": "Other Service / خدمة أخرى",
};

// POST /api/services-request  { service, email, details }
export async function onRequestPost({ request, env }) {
  const { service, email, details } = await request.json();
  if (!service || !email || !details) return json({ error: "missing fields" }, 400);

  await env.DB.prepare(
    "INSERT INTO service_requests (service, email, details, created_at) VALUES (?, ?, ?, ?)"
  ).bind(service, email, details, Date.now()).run();

  const label = SERVICE_LABELS[service] || service;

  // إرسال بريد إلى المؤسس عبر Resend — راجع README خطوة 5 لإنشاء مفتاح RESEND_API_KEY
  // Email the founder via Resend — see README step 5 to create RESEND_API_KEY
  try {
    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${env.RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: env.RESEND_FROM_EMAIL, // مثال: onboarding@yourdomain.com — لازم يكون نطاق تحقّقت منه في Resend
        to: env.FOUNDER_EMAIL,
        reply_to: email,
        subject: `New service request: ${label}`,
        html: `
          <h2>New service request</h2>
          <p><b>Service:</b> ${label}</p>
          <p><b>Client email:</b> ${email}</p>
          <p><b>Details:</b><br>${details.replace(/\n/g, "<br>")}</p>
        `,
      }),
    });
  } catch (e) {
    // حتى لو فشل إرسال البريد، الطلب محفوظ في قاعدة البيانات ويمكن مراجعته لاحقاً
    // Even if the email fails, the request is saved in the database for later review
  }

  return json({ ok: true });
}
