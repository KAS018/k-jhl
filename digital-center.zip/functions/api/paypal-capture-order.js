import { json } from "../_utils.js";

const PAYPAL_API = "https://api-m.sandbox.paypal.com"; // غيّرها إلى api-m.paypal.com في وضع Live

async function getAccessToken(env) {
  const auth = btoa(`${env.PAYPAL_CLIENT_ID}:${env.PAYPAL_SECRET}`);
  const res = await fetch(`${PAYPAL_API}/v1/oauth2/token`, {
    method: "POST",
    headers: { "Authorization": `Basic ${auth}`, "Content-Type": "application/x-www-form-urlencoded" },
    body: "grant_type=client_credentials",
  });
  return (await res.json()).access_token;
}

// POST /api/paypal-capture-order  { orderID }
export async function onRequestPost({ request, env }) {
  const { orderID } = await request.json();
  if (!orderID) return json({ error: "missing orderID" }, 400);

  const accessToken = await getAccessToken(env);
  const res = await fetch(`${PAYPAL_API}/v2/checkout/orders/${orderID}/capture`, {
    method: "POST",
    headers: { "Authorization": `Bearer ${accessToken}`, "Content-Type": "application/json" },
  });
  const capture = await res.json();
  return json(capture);
}
