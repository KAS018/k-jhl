import { json, randomCode } from "../_utils.js";

/* =========================================================================
   POST /api/generate-image
   محمي بمفتاح سرّي (X-Cron-Secret) — يُستدعى مرة يومياً من الـ Cron Worker
   المنفصل في worker-cron/ (راجع README خطوة 7).
   Protected by a shared secret (X-Cron-Secret) — called once a day by the
   separate Cron Worker in worker-cron/ (see README step 7).
   ========================================================================= */
export async function onRequestPost({ request, env }) {
  if (request.headers.get("X-Cron-Secret") !== env.CRON_SECRET) {
    return json({ error: "unauthorized" }, 401);
  }

  // 1) اطلب من Gemini فكرة + وصف للصورة النادرة اليوم (نص فقط)
  const ideaPrompt = `Invent ONE concept for a rare, one-of-a-kind piece of digital art (think: something a collector would bid on — an unusual creature, an impossible machine, a surreal landscape, an artifact from an imagined civilization). Reply strictly as JSON with keys: image_prompt (a vivid English prompt for an image generator, no text/watermarks in the image itself), description_en (1 sentence, enticing, for a marketplace listing), description_ar (same sentence translated naturally to Arabic).`;

  const ideaRes = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${env.GEMINI_API_KEY}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: ideaPrompt }] }],
        generationConfig: { responseMimeType: "application/json" },
      }),
    }
  );
  const ideaData = await ideaRes.json();
  let idea;
  try {
    idea = JSON.parse(ideaData.candidates[0].content.parts[0].text);
  } catch {
    return json({ error: "idea generation failed", raw: ideaData }, 500);
  }

  // 2) رمز فريد يُدمج داخل الطلب نفسه — يمنع توليد نفس الصورة مرة أخرى ويُستخدم كختم توثيق
  // Unique code baked into the prompt itself — prevents regenerating the same image and doubles as an authenticity stamp
  const code = randomCode(8);
  const imagePrompt = `${idea.image_prompt} Include a small subtle engraved authenticity mark reading "${code}" in a corner of the image, styled like a museum lot tag.`;

  // 3) توليد الصورة عبر Gemini (نموذج توليد الصور) — تحقق من اسم النموذج الحالي في Google AI Studio
  // Generate the image via Gemini's image model — verify the current model name in Google AI Studio, names change over time
  const imgRes = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${env.GEMINI_IMAGE_MODEL || "gemini-2.5-flash-image"}:generateContent?key=${env.GEMINI_API_KEY}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contents: [{ parts: [{ text: imagePrompt }] }] }),
    }
  );
  const imgData = await imgRes.json();
  let base64Image, mimeType;
  try {
    const part = imgData.candidates[0].content.parts.find((p) => p.inlineData);
    base64Image = part.inlineData.data;
    mimeType = part.inlineData.mimeType || "image/png";
  } catch {
    return json({ error: "image generation failed", raw: imgData }, 500);
  }

  // 4) رفع الصورة إلى R2
  const ext = mimeType.includes("jpeg") ? "jpg" : "png";
  const key = `rare/${Date.now()}-${code}.${ext}`;
  const bytes = Uint8Array.from(atob(base64Image), (c) => c.charCodeAt(0));
  await env.IMAGES_BUCKET.put(key, bytes, { httpMetadata: { contentType: mimeType } });
  const imageUrl = `${env.IMAGES_PUBLIC_BASE_URL}/${key}`;

  // 5) سعر عشوائي بين 1$ و100,000$ — أغلب الأيام سعر متواضع، ونادراً سعر ضخم (توزيع أسّي يحاكي الندرة الحقيقية)
  // Random price between $1–$100,000 — modest most days, rarely huge (exponential-ish distribution to mimic real rarity)
  const r = Math.random();
  const price = Math.round(1 + Math.pow(r, 4) * 99999 * 100) / 100;

  // الكمية غالباً 1 (نادرة فعلاً)، ونادراً حتى 3
  const quantity = Math.random() < 0.85 ? 1 : Math.ceil(Math.random() * 3);

  await env.DB.prepare(
    "INSERT INTO rare_images (image_url, description_ar, description_en, price, quantity, code, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)"
  ).bind(imageUrl, idea.description_ar, idea.description_en, price, quantity, code, Date.now()).run();

  return json({ ok: true, image_url: imageUrl, price, quantity, code });
}
