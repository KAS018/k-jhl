import { json, verifyPassword, signToken } from "../_utils.js";

// POST /api/login  { username, password } -> { token }
export async function onRequestPost({ request, env }) {
  const { username, password } = await request.json();
  if (!username || !password) return json({ error: "missing fields" }, 400);

  const row = await env.DB.prepare("SELECT username, password_hash FROM admins WHERE username = ?")
    .bind(username)
    .first();

  if (!row) return json({ error: "invalid credentials" }, 401);

  const ok = await verifyPassword(password, row.password_hash);
  if (!ok) return json({ error: "invalid credentials" }, 401);

  const token = await signToken(row.username, env.ADMIN_SESSION_SECRET);
  return json({ token });
}
