/* =========================================================================
   قسم خدماتي — مستقل تماماً. Services section — fully independent.
   عند إرسال الطلب: يُرسل بريد إلى بريد المؤسس عبر Resend (functions/api/services-request.js)
   ========================================================================= */
(function(){
  let currentLang = localStorage.getItem("dc_lang") || "ar";
  let selectedService = null;

  const cards = document.querySelectorAll("#services-section .service-card");
  const form = document.getElementById("serviceForm");

  function renderCardText(){
    cards.forEach(c=>{
      c.querySelector(".service-name").textContent = currentLang === "ar" ? c.dataset.arName : c.dataset.enName;
      c.querySelector(".service-desc").textContent = currentLang === "ar" ? c.dataset.arDesc : c.dataset.enDesc;
    });
  }
  renderCardText();

  cards.forEach(card=>{
    card.addEventListener("click", ()=>{
      cards.forEach(c=>c.classList.remove("selected"));
      card.classList.add("selected");
      selectedService = card.dataset.service;
      form.classList.add("open");
      form.scrollIntoView({ behavior:"smooth", block:"nearest" });
    });
  });

  document.getElementById("submitServiceBtn").addEventListener("click", async ()=>{
    const statusEl = document.getElementById("serviceFormStatus");
    const email = document.getElementById("serviceEmail").value.trim();
    const details = document.getElementById("serviceDetails").value.trim();

    if (!selectedService){
      statusEl.textContent = currentLang==="ar" ? "اختر خدمة أولاً" : "Pick a service first";
      statusEl.className = "form-status err";
      return;
    }
    if (!email || !details){
      statusEl.textContent = currentLang==="ar" ? "الرجاء تعبئة كل الحقول" : "Please fill in all fields";
      statusEl.className = "form-status err";
      return;
    }

    statusEl.textContent = currentLang==="ar" ? "جارٍ الإرسال..." : "Sending...";
    statusEl.className = "form-status";
    try{
      const res = await fetch("/api/services-request", {
        method:"POST",
        headers:{ "Content-Type":"application/json" },
        body: JSON.stringify({ service: selectedService, email, details })
      });
      if (!res.ok) throw new Error();
      statusEl.textContent = currentLang==="ar" ? "تم إرسال طلبك، سنتواصل معك قريباً" : "Your request has been sent — we'll be in touch soon";
      statusEl.className = "form-status ok";
      document.getElementById("serviceDetails").value = "";
    }catch(e){
      statusEl.textContent = currentLang==="ar" ? "تعذر إرسال الطلب" : "Could not send the request";
      statusEl.className = "form-status err";
    }
  });

  document.addEventListener("dc:langchange", (e)=>{ currentLang = e.detail.lang; renderCardText(); });
})();
