/* =========================================================================
   قسم الصور النادرة — مستقل تماماً عن باقي الأقسام.
   Rare Images section — fully independent from the other sections.
   ========================================================================= */
(function(){
  const grid = document.getElementById("rareImagesGrid");
  let currentLang = localStorage.getItem("dc_lang") || "ar";

  function esc(s){ return (s||"").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }

  function cardHtml(item){
    const desc = currentLang === "ar" ? item.description_ar : item.description_en;
    const isAdmin = window.dcAdmin && window.dcAdmin.isLoggedIn();
    return `
      <div class="lot-card" data-id="${item.id}">
        <div class="lot-media">
          <img src="${esc(item.image_url)}" alt="rare image" loading="lazy">
          <div class="lot-tag">LOT #${esc(item.code)}</div>
        </div>
        <div class="lot-body">
          <p class="lot-desc">${esc(desc)} <span class="ai-badge">AI</span></p>
          ${isAdmin ? `
            <div class="field"><input type="number" class="edit-price" value="${item.price}" step="0.01" min="1" max="100000"></div>
            <div class="field"><input type="number" class="edit-qty" value="${item.quantity}" min="1"></div>
            <button class="btn btn-sm btn-brass save-btn">${currentLang==="ar"?"حفظ":"Save"}</button>
          ` : `
            <div class="lot-foot">
              <span class="lot-price">$${Number(item.price).toLocaleString()}</span>
              <span class="lot-qty">${currentLang==="ar"?"الكمية":"Qty"}: ${item.quantity}</span>
            </div>
            <button class="btn btn-sm btn-brass buy-btn" style="margin-top:10px; width:100%;" data-price="${item.price}" data-kind="image" data-item-id="${item.id}">
              ${currentLang==="ar"?"شراء":"Buy"}
            </button>
            <div class="paypal-slot" style="margin-top:8px;"></div>
          `}
          <div class="lot-code">${currentLang==="ar"?"كود التحقق":"Auth code"}: ${esc(item.code)}</div>
        </div>
      </div>`;
  }

  async function wireBuyButtons(){
    const ready = await window.dcPaypalReady;
    grid.querySelectorAll(".buy-btn").forEach(btn=>{
      btn.addEventListener("click", ()=>{
        const slot = btn.nextElementSibling;
        if (!ready){
          slot.textContent = currentLang==="ar" ? "الدفع غير مُفعّل بعد" : "Payments not configured yet";
          return;
        }
        btn.style.display = "none";
        paypal.Buttons({
          createOrder: async ()=>{
            const res = await fetch("/api/paypal-create-order", {
              method:"POST", headers:{ "Content-Type":"application/json" },
              body: JSON.stringify({ kind:"image", item_id: btn.dataset.itemId, amount: btn.dataset.price })
            });
            const data = await res.json();
            return data.id;
          },
          onApprove: async (data)=>{
            await fetch("/api/paypal-capture-order", {
              method:"POST", headers:{ "Content-Type":"application/json" },
              body: JSON.stringify({ orderID: data.orderID })
            });
            slot.textContent = currentLang==="ar" ? "تم الدفع بنجاح" : "Payment successful";
          }
        }).render(slot);
      });
    });
  }

  async function loadImages(){
    try{
      const res = await fetch("/api/get-images");
      const data = await res.json();
      const items = data.items || [];
      grid.innerHTML = items.length
        ? items.map(cardHtml).join("")
        : `<div class="loading-placeholder">${currentLang==="ar"?"لا توجد صور بعد":"No images yet"}</div>`;

      grid.querySelectorAll(".save-btn").forEach(btn=>{
        btn.addEventListener("click", async (e)=>{
          const card = e.target.closest(".lot-card");
          const id = card.dataset.id;
          const price = card.querySelector(".edit-price").value;
          const quantity = card.querySelector(".edit-qty").value;
          await fetch("/api/admin-images", {
            method:"PATCH",
            headers:{ "Content-Type":"application/json", "Authorization": "Bearer " + window.dcAdmin.token() },
            body: JSON.stringify({ id, price, quantity })
          });
          loadImages();
        });
      });
      wireBuyButtons();
    }catch(e){
      grid.innerHTML = `<div class="loading-placeholder">${currentLang==="ar"?"تعذر تحميل الصور":"Could not load images"}</div>`;
    }
  }

  document.addEventListener("dc:langchange", (e)=>{ currentLang = e.detail.lang; loadImages(); });
  loadImages();
})();
