/* =========================================================================
   قسم الكتب — مستقل تماماً. Books section — fully independent.
   ========================================================================= */
(function(){
  const grid = document.getElementById("booksGrid");
  const addBtn = document.getElementById("addBookBtn");
  const form = document.getElementById("addBookForm");
  let currentLang = localStorage.getItem("dc_lang") || "ar";

  function esc(s){ return (s||"").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }

  function refreshAdminUI(){
    const isAdmin = window.dcAdmin && window.dcAdmin.isLoggedIn();
    addBtn.style.display = isAdmin ? "inline-block" : "none";
  }

  addBtn.addEventListener("click", ()=> form.classList.toggle("open"));

  document.getElementById("submitBookBtn").addEventListener("click", async ()=>{
    const statusEl = document.getElementById("bookFormStatus");
    const payload = {
      title_ar: document.getElementById("bookTitleAr").value.trim(),
      title_en: document.getElementById("bookTitleEn").value.trim(),
      cover_url: document.getElementById("bookCover").value.trim(),
      file_url: document.getElementById("bookFile").value.trim(),
      price: document.getElementById("bookPrice").value
    };
    statusEl.textContent = currentLang==="ar" ? "جارٍ النشر..." : "Publishing...";
    statusEl.className = "form-status";
    try{
      const res = await fetch("/api/admin-books", {
        method:"POST",
        headers:{ "Content-Type":"application/json", "Authorization":"Bearer " + window.dcAdmin.token() },
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new Error();
      statusEl.textContent = currentLang==="ar" ? "تم النشر" : "Published";
      statusEl.className = "form-status ok";
      form.classList.remove("open");
      loadBooks();
    }catch(e){
      statusEl.textContent = currentLang==="ar" ? "فشل النشر" : "Publish failed";
      statusEl.className = "form-status err";
    }
  });

  function cardHtml(book){
    const title = currentLang === "ar" ? book.title_ar : book.title_en;
    return `
      <div class="book-card" data-id="${book.id}">
        <div class="book-cover"><img src="${esc(book.cover_url)}" alt="${esc(title)}" loading="lazy"></div>
        <div class="book-info">
          <p class="book-title">${esc(title)}</p>
          <span class="book-price">$${Number(book.price).toLocaleString()}</span>
          <button class="btn btn-sm btn-brass buy-btn" style="margin-top:10px; width:100%;" data-price="${book.price}" data-item-id="${book.id}">
            ${currentLang==="ar"?"شراء":"Buy"}
          </button>
          <div class="paypal-slot" style="margin-top:8px;"></div>
        </div>
      </div>`;
  }

  async function wireBuyButtons(){
    const ready = await window.dcPaypalReady;
    grid.querySelectorAll(".buy-btn").forEach(btn=>{
      btn.addEventListener("click", ()=>{
        const slot = btn.nextElementSibling;
        if (!ready){ slot.textContent = currentLang==="ar" ? "الدفع غير مُفعّل بعد" : "Payments not configured yet"; return; }
        btn.style.display = "none";
        paypal.Buttons({
          createOrder: async ()=>{
            const res = await fetch("/api/paypal-create-order", {
              method:"POST", headers:{ "Content-Type":"application/json" },
              body: JSON.stringify({ kind:"book", item_id: btn.dataset.itemId, amount: btn.dataset.price })
            });
            return (await res.json()).id;
          },
          onApprove: async (data)=>{
            await fetch("/api/paypal-capture-order", {
              method:"POST", headers:{ "Content-Type":"application/json" },
              body: JSON.stringify({ orderID: data.orderID })
            });
            slot.textContent = currentLang==="ar" ? "تم الدفع — تحقق من بريدك لرابط التحميل" : "Payment successful — check your email for the download link";
          }
        }).render(slot);
      });
    });
  }

  async function loadBooks(){
    try{
      const res = await fetch("/api/get-books");
      const data = await res.json();
      const items = data.items || [];
      grid.innerHTML = items.length
        ? items.map(cardHtml).join("")
        : `<div class="loading-placeholder">${currentLang==="ar"?"لا توجد كتب بعد":"No books yet"}</div>`;
      wireBuyButtons();
    }catch(e){
      grid.innerHTML = `<div class="loading-placeholder">${currentLang==="ar"?"تعذر تحميل الكتب":"Could not load books"}</div>`;
    }
    refreshAdminUI();
  }

  document.addEventListener("dc:langchange", (e)=>{ currentLang = e.detail.lang; loadBooks(); });
  loadBooks();
})();
