/* =========================================================================
   قسم تنزيل الفيديوهات — مستقل تماماً.
   Video downloader section — fully independent.
   يستدعي /api/download الذي يتصل بخدمة تنزيل خارجية (راجع functions/api/download.js)
   ========================================================================= */
(function(){
  const btn = document.getElementById("downloadBtn");
  const input = document.getElementById("videoUrlInput");
  const status = document.getElementById("downloadStatus");
  let currentLang = localStorage.getItem("dc_lang") || "ar";

  btn.addEventListener("click", async ()=>{
    const url = input.value.trim();
    if (!url){
      status.textContent = currentLang==="ar" ? "ألصق رابط الفيديو أولاً" : "Paste a video link first";
      status.className = "form-status err";
      return;
    }
    status.textContent = currentLang==="ar" ? "جارٍ المعالجة..." : "Processing...";
    status.className = "form-status";
    try{
      const res = await fetch("/api/download", {
        method:"POST",
        headers:{ "Content-Type":"application/json" },
        body: JSON.stringify({ url })
      });
      const data = await res.json();
      if (res.ok && data.download_url){
        status.innerHTML = `<a href="${data.download_url}" target="_blank" rel="noopener" style="color:var(--brass); text-decoration:underline;">${currentLang==="ar"?"اضغط هنا لتنزيل الملف":"Click here to download"}</a>`;
        status.className = "form-status ok";
      } else {
        status.textContent = data.error || (currentLang==="ar" ? "تعذر معالجة الرابط" : "Could not process this link");
        status.className = "form-status err";
      }
    }catch(e){
      status.textContent = currentLang==="ar" ? "خطأ في الاتصال" : "Connection error";
      status.className = "form-status err";
    }
  });

  document.addEventListener("dc:langchange", (e)=>{ currentLang = e.detail.lang; });
})();
