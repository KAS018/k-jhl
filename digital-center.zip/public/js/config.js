/* =========================================================================
   إعدادات عامة (غير سرّية) — يمكن وضعها هنا مباشرة لأنها تظهر للمستخدم أصلاً.
   Public, NON-secret config — safe to hardcode because it's visible in the
   browser anyway. Real secrets (Gemini key, Resend key, PayPal SECRET,
   admin JWT secret) NEVER go in this file — they go in Cloudflare
   environment variables / secrets. See README.md step 6.
   ========================================================================= */

window.DC_CONFIG = {
  // ضع هنا الـ Client ID (وليس الـ Secret) من حساب مطوّري PayPal الخاص بك
  // Paste your PayPal Client ID (NOT the Secret) here
  PAYPAL_CLIENT_ID: "PASTE_YOUR_PAYPAL_CLIENT_ID_HERE",

  // روابط التواصل الاجتماعي — عدّلها هنا مرة واحدة فقط
  // Social links — edit once here
  SOCIAL: {
    tiktok:    "https://www.tiktok.com/@your-account",
    instagram: "https://www.instagram.com/your-account",
    youtube:   "https://www.youtube.com/@your-account",
    twitter:   "https://x.com/your-account"
  }
};

// يحدّث روابط الفوتر تلقائياً من الإعدادات أعلاه
document.addEventListener("DOMContentLoaded", ()=>{
  const s = window.DC_CONFIG.SOCIAL;
  const map = { "social-tiktok":"tiktok", "social-instagram":"instagram", "social-youtube":"youtube", "social-twitter":"twitter" };
  Object.entries(map).forEach(([elId, key])=>{
    const el = document.getElementById(elId);
    if (el && s[key]) el.href = s[key];
  });
});
