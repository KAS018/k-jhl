/* =========================================================================
   main.js — يجمع الأقسام في صفحة واحدة بالترتيب المحدد أدناه.
   لتغيير ترتيب الأقسام: غيّر ترتيب العناصر في SECTION_ORDER فقط.
   main.js — assembles all sections into one page, in this order.
   To reorder sections: change the order of items in SECTION_ORDER only.
   ========================================================================= */

// كل عنصر = قسم مستقل بالكامل (HTML خاص به + JS خاص به)
// Each entry = one fully self-contained section (own HTML + own JS)
const SECTION_ORDER = [
  { id: "rare-images", html: "/sections/rare-images.html", js: "/sections/rare-images.js" },
  { id: "books",       html: "/sections/books.html",       js: "/sections/books.js" },
  { id: "downloader",  html: "/sections/downloader.html",  js: "/sections/downloader.js" },
  { id: "services",    html: "/sections/services.html",    js: "/sections/services.js" },
];

// ---------------- Language (AR / EN) ----------------
const LANG_KEY = "dc_lang";
function getLang(){ return localStorage.getItem(LANG_KEY) || "ar"; }
function applyLang(lang){
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  document.querySelectorAll("[data-ar]").forEach(el=>{
    const val = lang === "ar" ? el.dataset.ar : el.dataset.en;
    if (val !== undefined) el.textContent = val;
  });
  document.getElementById("langToggle").textContent = lang === "ar" ? "EN" : "AR";
  localStorage.setItem(LANG_KEY, lang);
  document.dispatchEvent(new CustomEvent("dc:langchange", { detail:{ lang } }));
}
document.getElementById("langToggle").addEventListener("click", ()=>{
  applyLang(getLang() === "ar" ? "en" : "ar");
});

// ---------------- Admin session (shared helper for every section script) ----------------
// كل الأقسام تقدر تستخدم window.dcAdmin.isLoggedIn() / token() لمعرفة هل المدير داخل
window.dcAdmin = {
  isLoggedIn(){ return !!sessionStorage.getItem("dc_admin_token"); },
  token(){ return sessionStorage.getItem("dc_admin_token") || ""; },
  logout(){ sessionStorage.removeItem("dc_admin_token"); location.reload(); }
};

const modal = document.getElementById("adminModal");
document.getElementById("adminOpenBtn").addEventListener("click", ()=>{
  if (window.dcAdmin.isLoggedIn()){
    if (confirm(getLang()==="ar" ? "تسجيل الخروج؟" : "Log out?")) window.dcAdmin.logout();
    return;
  }
  modal.classList.add("open");
});
document.getElementById("adminCloseBtn").addEventListener("click", ()=> modal.classList.remove("open"));

document.getElementById("adminLoginSubmit").addEventListener("click", async ()=>{
  const username = document.getElementById("adminUsername").value.trim();
  const password = document.getElementById("adminPassword").value;
  const statusEl = document.getElementById("adminLoginStatus");
  statusEl.textContent = getLang()==="ar" ? "جارٍ التحقق..." : "Checking...";
  statusEl.className = "form-status";
  try{
    const res = await fetch("/api/login", {
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();
    if (res.ok && data.token){
      sessionStorage.setItem("dc_admin_token", data.token);
      statusEl.textContent = getLang()==="ar" ? "تم الدخول" : "Logged in";
      statusEl.className = "form-status ok";
      setTimeout(()=> location.reload(), 500);
    } else {
      statusEl.textContent = getLang()==="ar" ? "بيانات غير صحيحة" : "Invalid credentials";
      statusEl.className = "form-status err";
    }
  }catch(e){
    statusEl.textContent = getLang()==="ar" ? "خطأ في الاتصال" : "Connection error";
    statusEl.className = "form-status err";
  }
});

// ---------------- PayPal SDK (client-side, safe: only the public Client ID is used) ----------------
window.dcPaypalReady = new Promise((resolve)=>{
  const clientId = (window.DC_CONFIG && window.DC_CONFIG.PAYPAL_CLIENT_ID) || "";
  if (!clientId || clientId.includes("PASTE_YOUR")){ resolve(false); return; }
  const s = document.createElement("script");
  s.src = `https://www.paypal.com/sdk/js?client-id=${encodeURIComponent(clientId)}&currency=USD`;
  s.onload = ()=> resolve(true);
  s.onerror = ()=> resolve(false);
  document.head.appendChild(s);
});

// ---------------- Section loader ----------------
async function loadSections(){
  const root = document.getElementById("sections-root");
  for (const section of SECTION_ORDER){
    const wrapper = document.createElement("div");
    wrapper.id = `section-${section.id}`;
    wrapper.innerHTML = `<div class="loading-placeholder container">...</div>`;
    root.appendChild(wrapper);

    try{
      const html = await (await fetch(section.html)).text();
      wrapper.innerHTML = html;
    }catch(e){
      wrapper.innerHTML = `<div class="container loading-placeholder">Failed to load section: ${section.id}</div>`;
      continue;
    }

    // تحميل جافاسكربت القسم كـ module بعد إدراج الـ HTML الخاص فيه
    const script = document.createElement("script");
    script.type = "module";
    script.src = section.js + "?v=" + Date.now(); // avoid stale cache during dev
    document.body.appendChild(script);
  }
  applyLang(getLang());
}

loadSections();
