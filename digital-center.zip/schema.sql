-- قاعدة بيانات المركز الرقمي — Digital Center database schema

CREATE TABLE IF NOT EXISTS admins (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  username      TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS rare_images (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  image_url       TEXT NOT NULL,
  description_ar  TEXT NOT NULL,
  description_en  TEXT NOT NULL,
  price           REAL NOT NULL,
  quantity        INTEGER NOT NULL DEFAULT 1,
  code            TEXT NOT NULL,
  created_at      INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS books (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  title_ar    TEXT,
  title_en    TEXT,
  cover_url   TEXT,
  file_url    TEXT,
  price       REAL NOT NULL,
  created_at  INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS service_requests (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  service     TEXT NOT NULL,
  email       TEXT NOT NULL,
  details     TEXT NOT NULL,
  created_at  INTEGER NOT NULL
);
