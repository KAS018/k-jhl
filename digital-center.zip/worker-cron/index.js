/* =========================================================================
   Worker منفصل صغير مهمته الوحيدة: نداء رابط توليد الصورة اليومية في موقعك
   في وقت محدد كل يوم. يُنشر بشكل مستقل عن موقع Pages (راجع README خطوة 7).
   A tiny standalone Worker whose only job is to call your site's daily
   image-generation endpoint at a scheduled time. Deployed separately from
   the Pages site (see README step 7).
   ========================================================================= */
export default {
  async scheduled(event, env, ctx) {
    ctx.waitUntil(
      fetch(`${env.SITE_BASE_URL}/api/generate-image`, {
        method: "POST",
        headers: { "X-Cron-Secret": env.CRON_SECRET },
      })
    );
  },

  // يسمح لك باختباره يدوياً بفتح رابط الـ worker في المتصفح
  // Lets you trigger it manually by opening the worker's URL in a browser
  async fetch(request, env) {
    const res = await fetch(`${env.SITE_BASE_URL}/api/generate-image`, {
      method: "POST",
      headers: { "X-Cron-Secret": env.CRON_SECRET },
    });
    return new Response(await res.text(), { status: res.status });
  },
};
