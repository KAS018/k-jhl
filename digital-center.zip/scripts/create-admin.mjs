// أداة صغيرة لإنشاء حساب المدير — تعمل محلياً على جهازك فقط، لا تُنشر على الموقع.
// Small local tool to create the admin account — runs on your machine only, never deployed.
//
// الاستخدام / Usage:
//   node scripts/create-admin.mjs myusername "MyStrongPassword123"
//
// سيطبع لك أمر SQL جاهز، انسخه ونفّذه كما هو موضح في README خطوة 4.
// It prints a ready-made SQL command — copy it and run it as shown in README step 4.

const [username, password] = process.argv.slice(2);
if (!username || !password) {
  console.error("Usage: node scripts/create-admin.mjs <username> <password>");
  process.exit(1);
}

async function pbkdf2(password, saltBytes, iterations = 100000) {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt: saltBytes, iterations, hash: "SHA-256" },
    keyMaterial,
    256
  );
  return new Uint8Array(bits);
}
function toHex(bytes) {
  return [...bytes].map((b) => b.toString(16).padStart(2, "0")).join("");
}

const salt = crypto.getRandomValues(new Uint8Array(16));
const derived = await pbkdf2(password, salt);
const stored = `${toHex(salt)}:${toHex(derived)}`;

console.log("\n--- انسخ هذا السطر ونفّذه (README خطوة 4) / Copy & run this (README step 4) ---\n");
console.log(
  `wrangler d1 execute digital-center-db --remote --command "INSERT INTO admins (username, password_hash) VALUES ('${username}', '${stored}')"`
);
console.log("");
