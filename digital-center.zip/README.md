# المركز الرقمي — دليل التشغيل خطوة بخطوة

هذا المشروع كامل الأقسام، كل قسم بملف مستقل، ويتجمع تلقائياً في صفحة واحدة عبر `public/js/main.js`. لتعديل ترتيب الأقسام: افتح `public/js/main.js` وغيّر ترتيب `SECTION_ORDER` فقط.

> ملاحظة صادقة قبل البدء: هذا مشروع فعلي كامل (واجهة + قاعدة بيانات + دوال خادم) وليس عرضاً تجريبياً فقط. تحتاج فعلاً لتنفيذ كل خطوة أدناه بالترتيب حتى يعمل كل قسم (الدفع، البريد، توليد الصور اليومي). إذا تخطيت خطوة، القسم المرتبط بها فقط لن يعمل، والباقي يشتغل طبيعي.

---

## المتطلبات الأساسية

1. حساب [Cloudflare](https://dash.cloudflare.com) مجاني.
2. تثبيت Node.js من [nodejs.org](https://nodejs.org) (أي نسخة 18 أو أحدث).
3. تثبيت أداة Wrangler (أداة Cloudflare من سطر الأوامر):
   ```
   npm install -g wrangler
   wrangler login
   ```
   هذا الأمر سيفتح المتصفح ليطلب منك تسجيل الدخول لحساب Cloudflare — وافق.

---

## الخطوة 1 — افتح مشروع Pages في Cloudflare

1. في لوحة Cloudflare اذهب إلى **Workers & Pages** → **Create** → **Pages**.
2. اختر **Upload assets** (رفع مباشر) أو اربط مستودع GitHub إذا رفعت المشروع هناك — الأسهل هنا هو رفع مجلد المشروع مباشرة عبر Wrangler من جهازك (الخطوة 9 أدناه تشرح ذلك بالتفصيل)، فلا تحتاج GitHub إذا لا تريد.
3. اسم المشروع: `digital-center` (أو أي اسم تريده — إذا غيّرته، غيّره أيضاً في `wrangler.toml`).

---

## الخطوة 2 — أنشئ مفتاح Gemini (لتوليد الصور اليومية)

1. اذهب إلى [aistudio.google.com](https://aistudio.google.com).
2. سجّل دخول بحساب Google → اضغط **Get API Key** → **Create API key**.
3. انسخ المفتاح واحفظه جانباً (ستضعه في الخطوة 6).
4. **مهم:** تأكد أن الحساب عليه Billing مفعّل من [console.cloud.google.com](https://console.cloud.google.com) إذا أردت استخدام نموذج توليد الصور بدون حدود مجانية ضيّقة.

---

## الخطوة 3 — أنشئ قاعدة البيانات (D1) ومخزن الصور (R2)

من داخل مجلد المشروع في الطرفية (Terminal):

```bash
# إنشاء قاعدة البيانات
wrangler d1 create digital-center-db
```
سيطبع لك الأمر ناتجاً فيه `database_id` — انسخه، وافتح ملف `wrangler.toml` والصقه مكان `PASTE_YOUR_D1_DATABASE_ID_HERE`.

```bash
# تنفيذ هيكل الجداول
wrangler d1 execute digital-center-db --remote --file=./schema.sql

# إنشاء مخزن الصور
wrangler r2 bucket create digital-center-images
```

ثم فعّل الوصول العام لمخزن R2 حتى تظهر الصور في الموقع:
1. من لوحة Cloudflare: **R2** → اختر `digital-center-images` → **Settings** → **Public Access** → فعّله.
2. انسخ الرابط العام الذي يظهر لك (مثل `https://pub-xxxx.r2.dev`) — ستحتاجه في الخطوة 6 (`IMAGES_PUBLIC_BASE_URL`).

---

## الخطوة 4 — أنشئ حساب المدير (اسم مستخدم + كلمة مرور)

```bash
node scripts/create-admin.mjs myusername "MyStrongPassword123"
```

سيطبع لك سطر أمر جاهز يبدأ بـ `wrangler d1 execute...` — انسخه ونفّذه كما هو. هذا يضيف حسابك إلى جدول `admins` بكلمة مرور مشفّرة (لا تُحفظ كنص صريح أبداً).

يمكنك تكرار هذه الخطوة لاحقاً لإنشاء أكثر من حساب مدير.

---

## الخطوة 5 — أنشئ حساب Resend (لإرسال طلبات الخدمات إلى بريدك)

1. اذهب إلى [resend.com/onboarding](https://resend.com/onboarding) وأنشئ حساباً.
2. من لوحة Resend: **API Keys** → **Create API Key** → انسخه.
3. **يجب** إضافة نطاق (domain) تملكه والتحقق منه في Resend (قسم **Domains**) حتى تقدر ترسل من بريد مثل `noreply@yourdomain.com`. إذا لا تملك نطاقاً، Resend يوفر بريد تجريبي محدود للاختبار فقط — للاستخدام الحقيقي تحتاج نطاقاً.

---

## الخطوة 6 — أضف كل المفاتيح السرّية إلى Cloudflare (Secrets)

هذه الأوامر تُشغَّل من داخل مجلد المشروع. كل أمر سيسألك عن القيمة ثم يحفظها بأمان (لا تظهر في الكود أبداً):

```bash
wrangler pages secret put ADMIN_SESSION_SECRET --project-name digital-center
# اكتب أي نص عشوائي طويل وسري خاص بك، مثال: 9f8a7b6c5d4e...

wrangler pages secret put GEMINI_API_KEY --project-name digital-center
# مفتاح Gemini من الخطوة 2

wrangler pages secret put RESEND_API_KEY --project-name digital-center
# مفتاح Resend من الخطوة 5

wrangler pages secret put FOUNDER_EMAIL --project-name digital-center
# بريدك أنت (المؤسس) — وين توصلك طلبات العملاء

wrangler pages secret put RESEND_FROM_EMAIL --project-name digital-center
# مثال: noreply@yourdomain.com (النطاق الذي وثّقته في Resend)

wrangler pages secret put PAYPAL_CLIENT_ID --project-name digital-center
wrangler pages secret put PAYPAL_SECRET --project-name digital-center
# من حساب PayPal Developer (الخطوة 8)

wrangler pages secret put CRON_SECRET --project-name digital-center
# أي نص عشوائي سري — سيُستخدم بين الـ Cron Worker وموقعك فقط

wrangler pages secret put IMAGES_PUBLIC_BASE_URL --project-name digital-center
# الرابط العام لمخزن R2 من الخطوة 3، مثال: https://pub-xxxx.r2.dev

wrangler pages secret put GEMINI_IMAGE_MODEL --project-name digital-center
# اكتب: gemini-2.5-flash-image  (تحقق من اسم أحدث نموذج توليد صور في aistudio.google.com إذا تغيّر)
```

> ملاحظة: `PAYPAL_CLIENT_ID` هنا هو نسخة **سرّية للخادم**. الـ Client ID العام الذي يظهر للمتصفح موجود بشكل منفصل في `public/js/config.js` (نفس القيمة، لكن هذا طبيعي لأن الـ Client ID أصلاً غير سرّي — السرّي هو `PAYPAL_SECRET` فقط).

---

## الخطوة 7 — انشر موقعك، ثم انشر الـ Cron Worker المسؤول عن الصورة اليومية

نشر الموقع نفسه:
```bash
wrangler pages deploy public --project-name digital-center
```
سيعطيك رابط الموقع (مثل `https://digital-center.pages.dev`).

الآن انشر الـ Worker الصغير المسؤول عن توليد صورة كل يوم تلقائياً:
```bash
cd worker-cron
wrangler secret put SITE_BASE_URL
# الصق رابط موقعك من الأعلى، بدون / في النهاية

wrangler secret put CRON_SECRET
# نفس القيمة بالضبط التي وضعتها في الخطوة 6 لموقعك الرئيسي

wrangler deploy
cd ..
```
من الآن، الموقع سينشئ صورة نادرة جديدة تلقائياً كل يوم الساعة 06:00 (توقيت UTC). لتغيير الوقت، عدّل `crons` في `worker-cron/wrangler.toml` ثم أعد `wrangler deploy`.

**لاختبار الأمر فوراً بدون انتظار موعد الكرون:** افتح رابط الـ Worker الذي ظهر لك بعد `wrangler deploy` مباشرة في المتصفح.

---

## الخطوة 8 — (اختياري) اربط خدمة تنزيل الفيديوهات

قسم "تنزيل الفيديوهات" يعتمد على خدمة API خارجية جاهزة (وليس كود استخراج مكتوب من الصفر)، لأن كل منصة تغيّر بنيتها وشروطها باستمرار. أسهل طريقة:

1. افتح [rapidapi.com](https://rapidapi.com) وابحث عن "video downloader" أو "social media downloader" واشترك بإحدى الخدمات المتوفرة.
2. انسخ رابط الـ Endpoint ومفتاح الـ API الخاص بك من هناك.
3. نفّذ:
   ```bash
   wrangler pages secret put DOWNLOAD_API_URL --project-name digital-center
   wrangler pages secret put DOWNLOAD_API_KEY --project-name digital-center
   ```
4. افتح `functions/api/download.js` وعدّل اسم الحقل `data.download_url` إذا كانت الخدمة التي اخترتها تُرجع اسم حقل مختلف (كل خدمة توثيقها مختلف قليلاً).

---

## الخطوة 9 — أضف مفتاح PayPal (الوضع التجريبي ثم الحقيقي)

1. اذهب إلى [developer.paypal.com](https://developer.paypal.com) → **Apps & Credentials**.
2. في وضع **Sandbox** (تجريبي) ستجد تلقائياً تطبيقاً افتراضياً — انسخ منه `Client ID` و`Secret`.
3. ضع `Client ID` في مكانين:
   - سرّياً في Cloudflare (الخطوة 6، `PAYPAL_CLIENT_ID`).
   - علنياً في `public/js/config.js` بدل `PASTE_YOUR_PAYPAL_CLIENT_ID_HERE` (هذا طبيعي، فهو ليس سرّياً).
4. ضع `Secret` فقط في Cloudflare (`PAYPAL_SECRET`) — لا تضعه أبداً في أي ملف داخل `public/`.
5. جرّب الشراء بحساب Sandbox تجريبي (PayPal يعطيك حسابات وهمية للتجربة من نفس اللوحة).
6. عندما تكون جاهزاً للعمل الحقيقي: أنشئ تطبيق **Live** من نفس اللوحة، كرر نفس الخطوات بمفاتيحه، ثم افتح `functions/api/paypal-create-order.js` و`functions/api/paypal-capture-order.js` وغيّر:
   ```
   https://api-m.sandbox.paypal.com  →  https://api-m.paypal.com
   ```

---

## الخطوة 10 — روابط التواصل الاجتماعي

افتح `public/js/config.js` وعدّل الروابط الأربعة (تيك توك، انستغرام، يوتيوب، تويتر) بروابط حساباتك الفعلية.

---

## اختبار نهائي (Checklist)

- [ ] الموقع يفتح ويعرض الأقسام الأربعة بالترتيب.
- [ ] زر AR/EN يبدّل اللغة واتجاه الصفحة بالكامل.
- [ ] "دخول المدير" يعمل باسم المستخدم وكلمة المرور اللذين أنشأتهما في الخطوة 4.
- [ ] بعد الدخول كمدير: يظهر لك تعديل السعر/الكمية في قسم الصور، وزر "+ إضافة كتاب" في قسم الكتب.
- [ ] فتح رابط الـ Cron Worker يدوياً يولّد صورة جديدة فعلاً وتظهر في قسم الصور خلال ثوانٍ.
- [ ] إرسال طلب من قسم "خدماتي" يصل بريده إلى بريدك (الخطوة 5 + 6).
- [ ] الشراء التجريبي عبر PayPal Sandbox يكتمل بدون خطأ.

---

## كيف تعدّل قسماً بدون التأثير على الباقي

كل قسم = ملفان فقط داخل `public/sections/`: ملف `.html` وملف `.js` بنفس الاسم. عدّل الملفين الخاصين بالقسم الذي تريده فقط. لا حاجة لمس `index.html` أو `main.js` إلا إذا أردت تغيير **ترتيب** الأقسام (عندها عدّل `SECTION_ORDER` فقط في `public/js/main.js`).
